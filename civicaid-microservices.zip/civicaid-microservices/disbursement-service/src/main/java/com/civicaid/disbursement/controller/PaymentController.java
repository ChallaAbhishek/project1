package com.civicaid.disbursement.controller;

import com.civicaid.disbursement.dto.request.PaymentRequest;
import com.civicaid.disbursement.dto.response.PaymentResponse;
import com.civicaid.disbursement.entity.Payment;
import com.civicaid.disbursement.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    public ResponseEntity<PaymentResponse> initiate(@Valid @RequestBody PaymentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(paymentService.initiate(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<PaymentResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.getById(id));
    }

    @GetMapping("/disbursement/{disbursementId}")
    public ResponseEntity<List<PaymentResponse>> getByDisbursement(@PathVariable Long disbursementId) {
        return ResponseEntity.ok(paymentService.getByDisbursement(disbursementId));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<PaymentResponse> updateStatus(
            @PathVariable Long id,
            @RequestParam Payment.PaymentStatus status) {
        return ResponseEntity.ok(paymentService.updateStatus(id, status));
    }
}
