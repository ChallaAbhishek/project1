package com.civicaid.disbursement.dto.request;

import com.civicaid.disbursement.entity.Payment;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class PaymentRequest {
    @NotNull private Long disbursementId;
    @NotNull private Payment.PaymentMethod method;
    @NotNull private BigDecimal amount;
    private String transactionReference;
    private String bankAccountNumber;
    private String walletId;
}
