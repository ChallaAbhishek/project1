package com.civicaid.disbursement.controller;

import com.civicaid.disbursement.dto.request.DisbursementRequest;
import com.civicaid.disbursement.dto.response.DisbursementResponse;
import com.civicaid.disbursement.entity.Disbursement;
import com.civicaid.disbursement.service.DisbursementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/disbursements")
@RequiredArgsConstructor
public class DisbursementController {

    private final DisbursementService disbursementService;

    @PostMapping
    public ResponseEntity<DisbursementResponse> create(@Valid @RequestBody DisbursementRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(disbursementService.create(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<DisbursementResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(disbursementService.getById(id));
    }

    @GetMapping("/application/{applicationId}")
    public ResponseEntity<List<DisbursementResponse>> getByApplication(@PathVariable Long applicationId) {
        return ResponseEntity.ok(disbursementService.getByApplication(applicationId));
    }

    @GetMapping
    public ResponseEntity<Page<DisbursementResponse>> getAll(Pageable pageable) {
        return ResponseEntity.ok(disbursementService.getAll(pageable));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<DisbursementResponse> updateStatus(
            @PathVariable Long id,
            @RequestParam Disbursement.DisbursementStatus status) {
        return ResponseEntity.ok(disbursementService.updateStatus(id, status));
    }
}
