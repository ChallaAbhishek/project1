package com.civicaid.disbursement.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class DisbursementRequest {
    @NotNull private Long applicationId;
    @NotNull private BigDecimal amount;
    private String remarks;
}
