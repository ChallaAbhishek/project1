package com.civicaid.disbursement.repository;

import com.civicaid.disbursement.entity.Payment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByDisbursement_DisbursementId(Long disbursementId);
    Page<Payment> findByStatus(Payment.PaymentStatus status, Pageable pageable);
}
