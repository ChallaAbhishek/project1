package com.civicaid.disbursement.service;

import com.civicaid.disbursement.client.NotificationServiceClient;
import com.civicaid.disbursement.dto.request.PaymentRequest;
import com.civicaid.disbursement.dto.response.PaymentResponse;
import com.civicaid.disbursement.entity.Disbursement;
import com.civicaid.disbursement.entity.Payment;
import com.civicaid.disbursement.repository.DisbursementRepository;
import com.civicaid.disbursement.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final DisbursementRepository disbursementRepository;
    private final NotificationServiceClient notificationServiceClient;

    @Transactional
    public PaymentResponse initiate(PaymentRequest request) {
        Disbursement disbursement = disbursementRepository.findById(request.getDisbursementId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Disbursement not found: " + request.getDisbursementId()));

        Payment payment = Payment.builder()
                .disbursement(disbursement)
                .method(request.getMethod())
                .amount(request.getAmount())
                .bankAccountNumber(request.getBankAccountNumber())
                .walletId(request.getWalletId())
                .transactionReference(request.getTransactionReference())
                .build();

        payment = paymentRepository.save(payment);
        disbursement.setStatus(Disbursement.DisbursementStatus.PROCESSING);
        disbursementRepository.save(disbursement);

        if (disbursement.getCitizenUserId() != null) {
            NotificationServiceClient.NotificationRequest n = new NotificationServiceClient.NotificationRequest();
            n.setUserId(disbursement.getCitizenUserId());
            n.setEntityId(payment.getPaymentId());
            n.setMessage("Payment of ₹" + request.getAmount() + " initiated via " + request.getMethod().name());
            n.setCategory("DISBURSEMENT");
            notificationServiceClient.sendNotification(n);
        }

        return mapToResponse(payment);
    }

    public PaymentResponse getById(Long id) {
        return mapToResponse(paymentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Payment not found: " + id)));
    }

    public List<PaymentResponse> getByDisbursement(Long disbursementId) {
        return paymentRepository.findByDisbursement_DisbursementId(disbursementId)
                .stream().map(this::mapToResponse).toList();
    }

    @Transactional
    public PaymentResponse updateStatus(Long id, Payment.PaymentStatus status) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Payment not found: " + id));
        payment.setStatus(status);

        if (status == Payment.PaymentStatus.SUCCESS) {
            Disbursement d = payment.getDisbursement();
            d.setStatus(Disbursement.DisbursementStatus.COMPLETED);
            disbursementRepository.save(d);

            if (d.getCitizenUserId() != null) {
                NotificationServiceClient.NotificationRequest n = new NotificationServiceClient.NotificationRequest();
                n.setUserId(d.getCitizenUserId());
                n.setEntityId(payment.getPaymentId());
                n.setMessage("Payment of ₹" + payment.getAmount() + " completed successfully.");
                n.setCategory("DISBURSEMENT");
                notificationServiceClient.sendNotification(n);
            }
        }

        return mapToResponse(paymentRepository.save(payment));
    }

    private PaymentResponse mapToResponse(Payment p) {
        return PaymentResponse.builder()
                .paymentId(p.getPaymentId())
                .disbursementId(p.getDisbursement().getDisbursementId())
                .method(p.getMethod())
                .amount(p.getAmount())
                .transactionReference(p.getTransactionReference())
                .bankAccountNumber(p.getBankAccountNumber())
                .walletId(p.getWalletId())
                .date(p.getDate())
                .status(p.getStatus())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}
