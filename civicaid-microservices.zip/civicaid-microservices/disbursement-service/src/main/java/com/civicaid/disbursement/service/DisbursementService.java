package com.civicaid.disbursement.service;

import com.civicaid.disbursement.client.ApplicationServiceClient;
import com.civicaid.disbursement.client.NotificationServiceClient;
import com.civicaid.disbursement.dto.request.DisbursementRequest;
import com.civicaid.disbursement.dto.response.DisbursementResponse;
import com.civicaid.disbursement.entity.Disbursement;
import com.civicaid.disbursement.repository.DisbursementRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DisbursementService {

    private final DisbursementRepository disbursementRepository;
    private final ApplicationServiceClient applicationServiceClient;
    private final NotificationServiceClient notificationServiceClient;

    @Transactional
    public DisbursementResponse create(DisbursementRequest request) {
        ApplicationServiceClient.ApplicationInfo app =
                applicationServiceClient.getApplication(request.getApplicationId());

        if (!"APPROVED".equals(app.getStatus())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Disbursement can only be created for APPROVED applications");
        }

        Disbursement disbursement = Disbursement.builder()
                .applicationId(request.getApplicationId())
                .citizenUserId(app.getCitizenUserId())
                .citizenName(app.getCitizenName())
                .programTitle(app.getProgramTitle())
                .amount(request.getAmount())
                .remarks(request.getRemarks())
                .build();

        disbursement = disbursementRepository.save(disbursement);

        // Update application status to DISBURSED
        applicationServiceClient.updateStatus(request.getApplicationId(), "DISBURSED", null);

        // Notify citizen
        NotificationServiceClient.NotificationRequest notification = new NotificationServiceClient.NotificationRequest();
        notification.setUserId(app.getCitizenUserId());
        notification.setEntityId(disbursement.getDisbursementId());
        notification.setMessage("A disbursement of ₹" + request.getAmount() + " has been initiated for your application.");
        notification.setCategory("DISBURSEMENT");
        notificationServiceClient.sendNotification(notification);

        return mapToResponse(disbursement);
    }

    public DisbursementResponse getById(Long id) {
        return mapToResponse(disbursementRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Disbursement not found: " + id)));
    }

    public List<DisbursementResponse> getByApplication(Long applicationId) {
        return disbursementRepository.findByApplicationId(applicationId)
                .stream().map(this::mapToResponse).toList();
    }

    public Page<DisbursementResponse> getAll(Pageable pageable) {
        return disbursementRepository.findAll(pageable).map(this::mapToResponse);
    }

    @Transactional
    public DisbursementResponse updateStatus(Long id, Disbursement.DisbursementStatus status) {
        Disbursement d = disbursementRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Disbursement not found: " + id));
        d.setStatus(status);
        d = disbursementRepository.save(d);

        if (d.getCitizenUserId() != null) {
            NotificationServiceClient.NotificationRequest notification = new NotificationServiceClient.NotificationRequest();
            notification.setUserId(d.getCitizenUserId());
            notification.setEntityId(d.getDisbursementId());
            notification.setMessage("Your disbursement status has been updated to: " + status.name());
            notification.setCategory("DISBURSEMENT");
            notificationServiceClient.sendNotification(notification);
        }

        return mapToResponse(d);
    }

    private DisbursementResponse mapToResponse(Disbursement d) {
        return DisbursementResponse.builder()
                .disbursementId(d.getDisbursementId())
                .applicationId(d.getApplicationId())
                .citizenName(d.getCitizenName())
                .programTitle(d.getProgramTitle())
                .amount(d.getAmount())
                .date(d.getDate())
                .status(d.getStatus())
                .remarks(d.getRemarks())
                .updatedAt(d.getUpdatedAt())
                .build();
    }
}
