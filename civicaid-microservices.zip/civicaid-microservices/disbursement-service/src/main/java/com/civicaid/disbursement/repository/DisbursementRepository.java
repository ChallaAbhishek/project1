package com.civicaid.disbursement.repository;

import com.civicaid.disbursement.entity.Disbursement;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DisbursementRepository extends JpaRepository<Disbursement, Long> {
    List<Disbursement> findByApplicationId(Long applicationId);
    Page<Disbursement> findByStatus(Disbursement.DisbursementStatus status, Pageable pageable);
}
