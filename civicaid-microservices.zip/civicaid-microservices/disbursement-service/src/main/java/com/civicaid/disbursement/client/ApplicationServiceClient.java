package com.civicaid.disbursement.client;

import lombok.Data;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "application-service")
public interface ApplicationServiceClient {

    @GetMapping("/api/applications/{id}")
    ApplicationInfo getApplication(@PathVariable Long id);

    @PatchMapping("/api/applications/{id}/status")
    void updateStatus(@PathVariable Long id,
                      @RequestParam String status,
                      @RequestParam(required = false) String remarks);

    @Data
    class ApplicationInfo {
        private Long applicationId;
        private Long citizenId;
        private String citizenName;
        private Long programId;
        private String programTitle;
        private String status;
        private Long citizenUserId;
    }
}
