package com.civicaid.program.dto.request;

import com.civicaid.program.entity.Program;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ProgramRequest {
    @NotBlank private String title;
    private String description;
    @NotNull private LocalDate startDate;
    private LocalDate endDate;
    @NotNull private BigDecimal budget;
    private Program.ProgramStatus status;
}
