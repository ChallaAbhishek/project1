package com.civicaid.program.repository;

import com.civicaid.program.entity.Program;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProgramRepository extends JpaRepository<Program, Long> {
    Page<Program> findByStatus(Program.ProgramStatus status, Pageable pageable);
}
