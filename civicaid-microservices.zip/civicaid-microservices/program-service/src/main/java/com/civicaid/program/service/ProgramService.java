package com.civicaid.program.service;

import com.civicaid.program.dto.request.ProgramRequest;
import com.civicaid.program.dto.response.ProgramResponse;
import com.civicaid.program.entity.Program;
import com.civicaid.program.repository.ProgramRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class ProgramService {

    private final ProgramRepository programRepository;

    public ProgramResponse create(ProgramRequest request) {
        Program program = Program.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .startDate(request.getStartDate())
                .endDate(request.getEndDate())
                .budget(request.getBudget())
                .status(request.getStatus() != null ? request.getStatus() : Program.ProgramStatus.ACTIVE)
                .build();
        return mapToResponse(programRepository.save(program));
    }

    public ProgramResponse getById(Long id) {
        return mapToResponse(programRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Program not found: " + id)));
    }

    public Page<ProgramResponse> getAll(Pageable pageable) {
        return programRepository.findAll(pageable).map(this::mapToResponse);
    }

    public Page<ProgramResponse> getByStatus(Program.ProgramStatus status, Pageable pageable) {
        return programRepository.findByStatus(status, pageable).map(this::mapToResponse);
    }

    @Transactional
    public ProgramResponse update(Long id, ProgramRequest request) {
        Program program = programRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Program not found: " + id));
        program.setTitle(request.getTitle());
        program.setDescription(request.getDescription());
        program.setStartDate(request.getStartDate());
        program.setEndDate(request.getEndDate());
        program.setBudget(request.getBudget());
        if (request.getStatus() != null) program.setStatus(request.getStatus());
        return mapToResponse(programRepository.save(program));
    }

    private ProgramResponse mapToResponse(Program p) {
        return ProgramResponse.builder()
                .programId(p.getProgramId())
                .title(p.getTitle())
                .description(p.getDescription())
                .startDate(p.getStartDate())
                .endDate(p.getEndDate())
                .budget(p.getBudget())
                .status(p.getStatus())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}
