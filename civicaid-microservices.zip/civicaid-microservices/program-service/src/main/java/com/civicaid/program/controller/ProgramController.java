package com.civicaid.program.controller;

import com.civicaid.program.dto.request.ProgramRequest;
import com.civicaid.program.dto.response.ProgramResponse;
import com.civicaid.program.entity.Program;
import com.civicaid.program.service.ProgramService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/programs")
@RequiredArgsConstructor
public class ProgramController {

    private final ProgramService programService;

    @PostMapping
    public ResponseEntity<ProgramResponse> create(@Valid @RequestBody ProgramRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(programService.create(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProgramResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(programService.getById(id));
    }

    @GetMapping
    public ResponseEntity<Page<ProgramResponse>> getAll(Pageable pageable,
            @RequestParam(required = false) Program.ProgramStatus status) {
        if (status != null) return ResponseEntity.ok(programService.getByStatus(status, pageable));
        return ResponseEntity.ok(programService.getAll(pageable));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProgramResponse> update(@PathVariable Long id, @Valid @RequestBody ProgramRequest request) {
        return ResponseEntity.ok(programService.update(id, request));
    }
}
