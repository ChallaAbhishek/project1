package com.civicaid.program.dto.response;

import com.civicaid.program.entity.Program;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ProgramResponse {
    private Long programId;
    private String title;
    private String description;
    private LocalDate startDate;
    private LocalDate endDate;
    private BigDecimal budget;
    private Program.ProgramStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
