package com.civicaid.audit.controller;

import com.civicaid.audit.dto.request.AuditRequest;
import com.civicaid.audit.dto.response.AuditResponse;
import com.civicaid.audit.service.AuditService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/audits")
@RequiredArgsConstructor
public class AuditController {

    private final AuditService auditService;

    @PostMapping
    public ResponseEntity<AuditResponse> create(@Valid @RequestBody AuditRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(auditService.create(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<AuditResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(auditService.getById(id));
    }

    @GetMapping
    public ResponseEntity<Page<AuditResponse>> getAll(Pageable pageable) {
        return ResponseEntity.ok(auditService.getAll(pageable));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AuditResponse> update(@PathVariable Long id, @Valid @RequestBody AuditRequest request) {
        return ResponseEntity.ok(auditService.update(id, request));
    }
}
