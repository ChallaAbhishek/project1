package com.civicaid.audit.service;

import com.civicaid.audit.dto.request.ComplianceRequest;
import com.civicaid.audit.dto.response.ComplianceResponse;
import com.civicaid.audit.entity.ComplianceRecord;
import com.civicaid.audit.repository.ComplianceRecordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class ComplianceService {

    private final ComplianceRecordRepository complianceRepository;

    public ComplianceResponse create(ComplianceRequest request) {
        ComplianceRecord record = ComplianceRecord.builder()
                .entityId(request.getEntityId())
                .type(request.getType())
                .result(request.getResult())
                .notes(request.getNotes())
                .reviewedById(request.getReviewedById())
                .build();
        return mapToResponse(complianceRepository.save(record));
    }

    public ComplianceResponse getById(Long id) {
        return mapToResponse(complianceRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Compliance record not found: " + id)));
    }

    public Page<ComplianceResponse> getAll(Pageable pageable) {
        return complianceRepository.findAll(pageable).map(this::mapToResponse);
    }

    private ComplianceResponse mapToResponse(ComplianceRecord r) {
        return ComplianceResponse.builder()
                .complianceId(r.getComplianceId())
                .entityId(r.getEntityId())
                .type(r.getType())
                .result(r.getResult())
                .date(r.getDate())
                .notes(r.getNotes())
                .reviewedById(r.getReviewedById())
                .build();
    }
}
