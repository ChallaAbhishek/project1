package com.civicaid.audit.controller;

import com.civicaid.audit.dto.request.AuditLogRequest;
import com.civicaid.audit.dto.response.AuditLogResponse;
import com.civicaid.audit.service.AuditLogService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/audit-logs")
@RequiredArgsConstructor
public class AuditLogController {

    private final AuditLogService auditLogService;

    @PostMapping
    public ResponseEntity<Void> log(@Valid @RequestBody AuditLogRequest request) {
        auditLogService.log(request);
        return ResponseEntity.accepted().build();
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<Page<AuditLogResponse>> getByUser(@PathVariable Long userId, Pageable pageable) {
        return ResponseEntity.ok(auditLogService.getByUser(userId, pageable));
    }

    @GetMapping
    public ResponseEntity<Page<AuditLogResponse>> getAll(Pageable pageable) {
        return ResponseEntity.ok(auditLogService.getAll(pageable));
    }
}
