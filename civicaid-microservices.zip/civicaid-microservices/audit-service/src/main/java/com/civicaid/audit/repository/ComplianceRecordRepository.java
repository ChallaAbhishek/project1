package com.civicaid.audit.repository;

import com.civicaid.audit.entity.ComplianceRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComplianceRecordRepository extends JpaRepository<ComplianceRecord, Long> {
    Page<ComplianceRecord> findByType(ComplianceRecord.EntityType type, Pageable pageable);
    Page<ComplianceRecord> findByResult(ComplianceRecord.ComplianceResult result, Pageable pageable);
}
