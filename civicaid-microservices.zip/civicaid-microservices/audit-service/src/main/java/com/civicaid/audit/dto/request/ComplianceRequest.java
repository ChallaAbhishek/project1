package com.civicaid.audit.dto.request;

import com.civicaid.audit.entity.ComplianceRecord;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ComplianceRequest {
    @NotNull private Long entityId;
    @NotNull private ComplianceRecord.EntityType type;
    @NotNull private ComplianceRecord.ComplianceResult result;
    private String notes;
    private Long reviewedById;
}
