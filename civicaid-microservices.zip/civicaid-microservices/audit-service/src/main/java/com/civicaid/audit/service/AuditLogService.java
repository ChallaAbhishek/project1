package com.civicaid.audit.service;

import com.civicaid.audit.dto.request.AuditLogRequest;
import com.civicaid.audit.dto.response.AuditLogResponse;
import com.civicaid.audit.entity.AuditLog;
import com.civicaid.audit.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    @Async
    public void log(AuditLogRequest request) {
        AuditLog log = AuditLog.builder()
                .userId(request.getUserId())
                .action(request.getAction())
                .entityType(request.getEntityType())
                .details(request.getDetails())
                .ipAddress(request.getIpAddress())
                .build();
        auditLogRepository.save(log);
    }

    public Page<AuditLogResponse> getByUser(Long userId, Pageable pageable) {
        return auditLogRepository.findByUserId(userId, pageable).map(this::mapToResponse);
    }

    public Page<AuditLogResponse> getAll(Pageable pageable) {
        return auditLogRepository.findAll(pageable).map(this::mapToResponse);
    }

    private AuditLogResponse mapToResponse(AuditLog l) {
        return AuditLogResponse.builder()
                .logId(l.getLogId())
                .userId(l.getUserId())
                .action(l.getAction())
                .entityType(l.getEntityType())
                .details(l.getDetails())
                .ipAddress(l.getIpAddress())
                .timestamp(l.getTimestamp())
                .build();
    }
}
