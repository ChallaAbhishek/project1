package com.civicaid.audit.dto.response;

import com.civicaid.audit.entity.ComplianceRecord;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ComplianceResponse {
    private Long complianceId;
    private Long entityId;
    private ComplianceRecord.EntityType type;
    private ComplianceRecord.ComplianceResult result;
    private LocalDateTime date;
    private String notes;
    private Long reviewedById;
}
