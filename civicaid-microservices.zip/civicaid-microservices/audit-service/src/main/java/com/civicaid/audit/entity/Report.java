package com.civicaid.audit.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "reports")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reportId;

    @Column(nullable = false)
    private String title;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ReportScope scope;

    @Column(columnDefinition = "TEXT")
    private String content;

    private Long generatedById;

    @CreationTimestamp
    private LocalDateTime generatedAt;

    public enum ReportScope { PROGRAM, CITIZEN, DISBURSEMENT, COMPLIANCE, SYSTEM }
}
