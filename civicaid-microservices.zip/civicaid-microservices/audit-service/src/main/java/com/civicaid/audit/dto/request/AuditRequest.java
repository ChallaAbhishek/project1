package com.civicaid.audit.dto.request;

import com.civicaid.audit.entity.Audit;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AuditRequest {
    @NotNull  private Long officerId;
    private String officerName;
    @NotBlank private String scope;
    private String findings;
    private Audit.AuditStatus status;
}
