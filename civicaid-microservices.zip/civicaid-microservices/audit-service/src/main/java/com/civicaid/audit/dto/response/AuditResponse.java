package com.civicaid.audit.dto.response;

import com.civicaid.audit.entity.Audit;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AuditResponse {
    private Long auditId;
    private Long officerId;
    private String officerName;
    private String scope;
    private String findings;
    private LocalDateTime date;
    private Audit.AuditStatus status;
    private LocalDateTime updatedAt;
}
