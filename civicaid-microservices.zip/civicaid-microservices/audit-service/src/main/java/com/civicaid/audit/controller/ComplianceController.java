package com.civicaid.audit.controller;

import com.civicaid.audit.dto.request.ComplianceRequest;
import com.civicaid.audit.dto.response.ComplianceResponse;
import com.civicaid.audit.service.ComplianceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/compliance")
@RequiredArgsConstructor
public class ComplianceController {

    private final ComplianceService complianceService;

    @PostMapping
    public ResponseEntity<ComplianceResponse> create(@Valid @RequestBody ComplianceRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(complianceService.create(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComplianceResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(complianceService.getById(id));
    }

    @GetMapping
    public ResponseEntity<Page<ComplianceResponse>> getAll(Pageable pageable) {
        return ResponseEntity.ok(complianceService.getAll(pageable));
    }
}
