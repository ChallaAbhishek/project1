package com.civicaid.audit.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AuditLogRequest {
    @NotNull  private Long userId;
    @NotBlank private String action;
    @NotBlank private String entityType;
    private String details;
    private String ipAddress;
}
