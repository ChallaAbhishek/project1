package com.civicaid.audit.repository;

import com.civicaid.audit.entity.Report;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<Report, Long> {
    Page<Report> findByScope(Report.ReportScope scope, Pageable pageable);
}
