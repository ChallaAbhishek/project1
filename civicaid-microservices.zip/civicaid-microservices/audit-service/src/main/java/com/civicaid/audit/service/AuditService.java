package com.civicaid.audit.service;

import com.civicaid.audit.dto.request.AuditRequest;
import com.civicaid.audit.dto.response.AuditResponse;
import com.civicaid.audit.entity.Audit;
import com.civicaid.audit.repository.AuditRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditRepository auditRepository;

    public AuditResponse create(AuditRequest request) {
        Audit audit = Audit.builder()
                .officerId(request.getOfficerId())
                .officerName(request.getOfficerName())
                .scope(request.getScope())
                .findings(request.getFindings())
                .status(request.getStatus() != null ? request.getStatus() : Audit.AuditStatus.SCHEDULED)
                .build();
        return mapToResponse(auditRepository.save(audit));
    }

    public AuditResponse getById(Long id) {
        return mapToResponse(auditRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Audit not found: " + id)));
    }

    public Page<AuditResponse> getAll(Pageable pageable) {
        return auditRepository.findAll(pageable).map(this::mapToResponse);
    }

    @Transactional
    public AuditResponse update(Long id, AuditRequest request) {
        Audit audit = auditRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Audit not found: " + id));
        audit.setScope(request.getScope());
        audit.setFindings(request.getFindings());
        if (request.getStatus() != null) audit.setStatus(request.getStatus());
        return mapToResponse(auditRepository.save(audit));
    }

    private AuditResponse mapToResponse(Audit a) {
        return AuditResponse.builder()
                .auditId(a.getAuditId())
                .officerId(a.getOfficerId())
                .officerName(a.getOfficerName())
                .scope(a.getScope())
                .findings(a.getFindings())
                .date(a.getDate())
                .status(a.getStatus())
                .updatedAt(a.getUpdatedAt())
                .build();
    }
}
