package com.civicaid.audit.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AuditLogResponse {
    private Long logId;
    private Long userId;
    private String action;
    private String entityType;
    private String details;
    private String ipAddress;
    private LocalDateTime timestamp;
}
