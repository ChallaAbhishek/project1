package com.civicaid.audit.repository;

import com.civicaid.audit.entity.Audit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditRepository extends JpaRepository<Audit, Long> {
    Page<Audit> findByStatus(Audit.AuditStatus status, Pageable pageable);
    Page<Audit> findByOfficerId(Long officerId, Pageable pageable);
}
