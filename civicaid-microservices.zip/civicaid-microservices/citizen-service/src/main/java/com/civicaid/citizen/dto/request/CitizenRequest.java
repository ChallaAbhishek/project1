package com.civicaid.citizen.dto.request;

import com.civicaid.citizen.entity.Citizen;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class CitizenRequest {
    @NotBlank private String name;
    @NotNull private LocalDate dob;
    private Citizen.Gender gender;
    private String address;
    private String contactInfo;
}
