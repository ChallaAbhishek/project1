package com.civicaid.citizen.service;

import com.civicaid.citizen.dto.request.CitizenRequest;
import com.civicaid.citizen.dto.response.CitizenResponse;
import com.civicaid.citizen.entity.Citizen;
import com.civicaid.citizen.exception.ResourceNotFoundException;
import com.civicaid.citizen.repository.CitizenRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class CitizenService {

    private final CitizenRepository citizenRepository;

    public CitizenResponse createProfile(Long userId, CitizenRequest request) {
        if (citizenRepository.existsByUserId(userId)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Citizen profile already exists for this user");
        }
        Citizen citizen = Citizen.builder()
                .userId(userId)
                .name(request.getName())
                .dob(request.getDob())
                .gender(request.getGender())
                .address(request.getAddress())
                .contactInfo(request.getContactInfo())
                .build();
        return mapToResponse(citizenRepository.save(citizen));
    }

    public CitizenResponse getById(Long id) {
        return mapToResponse(citizenRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen", id)));
    }

    public CitizenResponse getByUserId(Long userId) {
        return mapToResponse(citizenRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen profile for userId", userId)));
    }

    public Page<CitizenResponse> getAll(Pageable pageable) {
        return citizenRepository.findAll(pageable).map(this::mapToResponse);
    }

    public Page<CitizenResponse> getByStatus(Citizen.CitizenStatus status, Pageable pageable) {
        return citizenRepository.findByStatus(status, pageable).map(this::mapToResponse);
    }

    @Transactional
    public CitizenResponse updateStatus(Long id, Citizen.CitizenStatus status) {
        Citizen citizen = citizenRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen", id));
        citizen.setStatus(status);
        return mapToResponse(citizenRepository.save(citizen));
    }

    @Transactional
    public CitizenResponse updateProfile(Long id, CitizenRequest request) {
        Citizen citizen = citizenRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen", id));
        citizen.setName(request.getName());
        citizen.setDob(request.getDob());
        citizen.setGender(request.getGender());
        citizen.setAddress(request.getAddress());
        citizen.setContactInfo(request.getContactInfo());
        return mapToResponse(citizenRepository.save(citizen));
    }

    private CitizenResponse mapToResponse(Citizen c) {
        return CitizenResponse.builder()
                .citizenId(c.getCitizenId())
                .userId(c.getUserId())
                .name(c.getName())
                .dob(c.getDob())
                .gender(c.getGender())
                .address(c.getAddress())
                .contactInfo(c.getContactInfo())
                .status(c.getStatus())
                .createdAt(c.getCreatedAt())
                .updatedAt(c.getUpdatedAt())
                .build();
    }
}
