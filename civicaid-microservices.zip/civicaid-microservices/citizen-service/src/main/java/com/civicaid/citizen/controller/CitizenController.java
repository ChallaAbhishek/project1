package com.civicaid.citizen.controller;

import com.civicaid.citizen.dto.request.CitizenRequest;
import com.civicaid.citizen.dto.response.CitizenResponse;
import com.civicaid.citizen.entity.Citizen;
import com.civicaid.citizen.service.CitizenService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/citizens")
@RequiredArgsConstructor
public class CitizenController {

    private final CitizenService citizenService;

    @PostMapping
    public ResponseEntity<CitizenResponse> create(
            @RequestHeader("X-User-Id") Long userId,
            @Valid @RequestBody CitizenRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(citizenService.createProfile(userId, request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CitizenResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(citizenService.getById(id));
    }

    @GetMapping("/by-user/{userId}")
    public ResponseEntity<CitizenResponse> getByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(citizenService.getByUserId(userId));
    }

    @GetMapping
    public ResponseEntity<Page<CitizenResponse>> getAll(Pageable pageable) {
        return ResponseEntity.ok(citizenService.getAll(pageable));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CitizenResponse> update(@PathVariable Long id, @Valid @RequestBody CitizenRequest request) {
        return ResponseEntity.ok(citizenService.updateProfile(id, request));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<CitizenResponse> updateStatus(
            @PathVariable Long id,
            @RequestParam Citizen.CitizenStatus status) {
        return ResponseEntity.ok(citizenService.updateStatus(id, status));
    }
}
