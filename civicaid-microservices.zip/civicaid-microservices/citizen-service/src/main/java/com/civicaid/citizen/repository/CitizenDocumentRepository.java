package com.civicaid.citizen.repository;

import com.civicaid.citizen.entity.CitizenDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CitizenDocumentRepository extends JpaRepository<CitizenDocument, Long> {
    List<CitizenDocument> findByCitizen_CitizenId(Long citizenId);
}
