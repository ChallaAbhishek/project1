package com.civicaid.citizen.repository;

import com.civicaid.citizen.entity.Citizen;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CitizenRepository extends JpaRepository<Citizen, Long> {
    Optional<Citizen> findByUserId(Long userId);
    Page<Citizen> findByStatus(Citizen.CitizenStatus status, Pageable pageable);
    boolean existsByUserId(Long userId);
}
