package com.civicaid.citizen.dto.response;

import com.civicaid.citizen.entity.Citizen;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CitizenResponse {
    private Long citizenId;
    private Long userId;
    private String name;
    private LocalDate dob;
    private Citizen.Gender gender;
    private String address;
    private String contactInfo;
    private Citizen.CitizenStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
