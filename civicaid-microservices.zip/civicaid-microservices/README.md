# CivicAid Microservices Architecture

## Services Overview

| Service              | Port | Database                        | Description                              |
|----------------------|------|---------------------------------|------------------------------------------|
| eureka-server        | 8761 | —                               | Service Registry (Netflix Eureka)        |
| api-gateway          | 8080 | —                               | API Gateway with JWT validation          |
| auth-service         | 8081 | civicaid_auth_service           | Authentication & User management         |
| citizen-service      | 8082 | civicaid_citizen_service        | Citizen profiles & document management  |
| program-service      | 8083 | civicaid_program_service        | Programs & Schemes catalog               |
| application-service  | 8084 | civicaid_application_service    | Welfare applications & eligibility       |
| disbursement-service | 8085 | civicaid_disbursement_service   | Disbursements & Payments                 |
| notification-service | 8086 | civicaid_notification_service   | Notifications                            |
| audit-service        | 8087 | civicaid_audit_service          | Audit logs, Compliance & Reports         |

## Quick Start

### Prerequisites
- Java 21+
- Maven 3.9+
- Docker & Docker Compose
- MySQL 8.0 (or use Docker)

### Run with Docker Compose
```bash
docker-compose up -d
```

### Run locally (start in order)
```bash
# 1. Start Eureka Server
cd eureka-server && mvn spring-boot:run

# 2. Start API Gateway
cd api-gateway && mvn spring-boot:run

# 3. Start all business services (separate terminals)
cd auth-service && mvn spring-boot:run
cd citizen-service && mvn spring-boot:run
cd program-service && mvn spring-boot:run
cd application-service && mvn spring-boot:run
cd disbursement-service && mvn spring-boot:run
cd notification-service && mvn spring-boot:run
cd audit-service && mvn spring-boot:run
```

## API Endpoints (via Gateway on port 8080)

### Auth
- POST /api/auth/register
- POST /api/auth/login

### Citizens
- POST   /api/citizens
- GET    /api/citizens/{id}
- GET    /api/citizens/by-user/{userId}
- PUT    /api/citizens/{id}
- PATCH  /api/citizens/{id}/status

### Programs
- POST   /api/programs
- GET    /api/programs
- GET    /api/programs/{id}
- PUT    /api/programs/{id}

### Applications
- POST   /api/applications/citizen/{citizenId}
- GET    /api/applications/{id}
- GET    /api/applications/citizen/{citizenId}
- PATCH  /api/applications/{id}/status

### Disbursements
- POST   /api/disbursements
- GET    /api/disbursements/{id}
- GET    /api/disbursements/application/{applicationId}
- PATCH  /api/disbursements/{id}/status

### Payments
- POST   /api/payments
- GET    /api/payments/{id}
- PATCH  /api/payments/{id}/status

### Notifications
- GET    /api/notifications/user/{userId}
- GET    /api/notifications/user/{userId}/unread
- PATCH  /api/notifications/{id}/read

### Audits
- POST   /api/audits
- GET    /api/audits/{id}
- POST   /api/audit-logs
- GET    /api/audit-logs
- POST   /api/compliance
- GET    /api/compliance/{id}

## Architecture Notes

### JWT Flow
1. Client sends credentials to `/api/auth/login`
2. auth-service issues a JWT token containing userId, email, role
3. All subsequent requests include `Authorization: Bearer <token>`
4. API Gateway validates the token and injects `X-User-Id`, `X-User-Email`, `X-User-Role` headers
5. Downstream services read these headers — no re-validation needed

### Inter-Service Communication
- Synchronous: OpenFeign REST calls (application → citizen, application → program, disbursement → application)
- Asynchronous: Direct REST calls to notification-service (fire-and-forget pattern)
- Future: Replace notification calls with Kafka events for full decoupling

### Database Strategy
Each service has its own MySQL database schema. Cross-service data is accessed via REST API calls only.
Foreign keys across services are replaced by logical ID references (Long fields).
