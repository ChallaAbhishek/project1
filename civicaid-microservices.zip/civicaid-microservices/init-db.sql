-- CivicAid Microservices DB Initialization
CREATE DATABASE IF NOT EXISTS civicaid_auth_service;
CREATE DATABASE IF NOT EXISTS civicaid_citizen_service;
CREATE DATABASE IF NOT EXISTS civicaid_program_service;
CREATE DATABASE IF NOT EXISTS civicaid_application_service;
CREATE DATABASE IF NOT EXISTS civicaid_disbursement_service;
CREATE DATABASE IF NOT EXISTS civicaid_notification_service;
CREATE DATABASE IF NOT EXISTS civicaid_audit_service;
