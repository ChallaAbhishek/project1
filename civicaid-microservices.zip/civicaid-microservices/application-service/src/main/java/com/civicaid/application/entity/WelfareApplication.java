package com.civicaid.application.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "welfare_applications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class WelfareApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long applicationId;

    @Column(nullable = false)
    private Long citizenId;   // logical ref to citizen-service

    @Column(nullable = false)
    private Long programId;   // logical ref to program-service

    private Long schemeId;    // logical ref to program-service

    private String citizenName;
    private String programTitle;
    private String schemeTitle;

    @CreationTimestamp
    private LocalDateTime submittedDate;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ApplicationStatus status = ApplicationStatus.SUBMITTED;

    @Column(columnDefinition = "TEXT")
    private String remarks;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public enum ApplicationStatus {
        SUBMITTED, UNDER_REVIEW, ELIGIBLE, INELIGIBLE, APPROVED, REJECTED, DISBURSED, CLOSED
    }
}
