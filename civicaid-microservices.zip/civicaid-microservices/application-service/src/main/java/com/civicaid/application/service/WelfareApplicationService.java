package com.civicaid.application.service;

import com.civicaid.application.client.CitizenServiceClient;
import com.civicaid.application.client.ProgramServiceClient;
import com.civicaid.application.dto.request.WelfareApplicationRequest;
import com.civicaid.application.dto.response.WelfareApplicationResponse;
import com.civicaid.application.entity.WelfareApplication;
import com.civicaid.application.repository.WelfareApplicationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class WelfareApplicationService {

    private final WelfareApplicationRepository applicationRepository;
    private final CitizenServiceClient citizenServiceClient;
    private final ProgramServiceClient programServiceClient;

    @Transactional
    public WelfareApplicationResponse submit(Long citizenId, WelfareApplicationRequest request) {
        // Validate citizen is VERIFIED via Feign
        CitizenServiceClient.CitizenInfo citizen = citizenServiceClient.getCitizen(citizenId);
        if (!"VERIFIED".equals(citizen.getStatus())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Citizen profile must be verified");
        }

        if (applicationRepository.existsByCitizenIdAndProgramId(citizenId, request.getProgramId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Application already submitted for this program");
        }

        // Validate program is ACTIVE via Feign
        ProgramServiceClient.ProgramInfo program = programServiceClient.getProgram(request.getProgramId());
        if (!"ACTIVE".equals(program.getStatus())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Program is not currently accepting applications");
        }

        WelfareApplication app = WelfareApplication.builder()
                .citizenId(citizenId)
                .citizenName(citizen.getName())
                .programId(request.getProgramId())
                .programTitle(program.getTitle())
                .schemeId(request.getSchemeId())
                .remarks(request.getRemarks())
                .build();

        return mapToResponse(applicationRepository.save(app));
    }

    public WelfareApplicationResponse getById(Long id) {
        return mapToResponse(applicationRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Application not found: " + id)));
    }

    public Page<WelfareApplicationResponse> getByCitizen(Long citizenId, Pageable pageable) {
        return applicationRepository.findByCitizenId(citizenId, pageable).map(this::mapToResponse);
    }

    public Page<WelfareApplicationResponse> getAll(Pageable pageable) {
        return applicationRepository.findAll(pageable).map(this::mapToResponse);
    }

    @Transactional
    public WelfareApplicationResponse updateStatus(Long id, WelfareApplication.ApplicationStatus status, String remarks) {
        WelfareApplication app = applicationRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Application not found: " + id));
        app.setStatus(status);
        if (remarks != null) app.setRemarks(remarks);
        return mapToResponse(applicationRepository.save(app));
    }

    private WelfareApplicationResponse mapToResponse(WelfareApplication a) {
        return WelfareApplicationResponse.builder()
                .applicationId(a.getApplicationId())
                .citizenId(a.getCitizenId())
                .citizenName(a.getCitizenName())
                .programId(a.getProgramId())
                .programTitle(a.getProgramTitle())
                .schemeId(a.getSchemeId())
                .schemeTitle(a.getSchemeTitle())
                .submittedDate(a.getSubmittedDate())
                .status(a.getStatus())
                .remarks(a.getRemarks())
                .updatedAt(a.getUpdatedAt())
                .build();
    }
}
