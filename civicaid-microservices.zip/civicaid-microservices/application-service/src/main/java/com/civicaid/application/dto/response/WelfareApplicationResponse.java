package com.civicaid.application.dto.response;

import com.civicaid.application.entity.WelfareApplication;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class WelfareApplicationResponse {
    private Long applicationId;
    private Long citizenId;
    private String citizenName;
    private Long programId;
    private String programTitle;
    private Long schemeId;
    private String schemeTitle;
    private LocalDateTime submittedDate;
    private WelfareApplication.ApplicationStatus status;
    private String remarks;
    private LocalDateTime updatedAt;
}
