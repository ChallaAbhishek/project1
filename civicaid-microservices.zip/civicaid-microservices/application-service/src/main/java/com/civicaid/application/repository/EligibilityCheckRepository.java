package com.civicaid.application.repository;

import com.civicaid.application.entity.EligibilityCheck;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface EligibilityCheckRepository extends JpaRepository<EligibilityCheck, Long> {
    List<EligibilityCheck> findByApplication_ApplicationId(Long applicationId);
    Optional<EligibilityCheck> findTopByApplication_ApplicationIdOrderByDateDesc(Long applicationId);
}
