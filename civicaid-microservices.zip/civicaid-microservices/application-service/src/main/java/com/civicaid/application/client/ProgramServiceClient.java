package com.civicaid.application.client;

import lombok.Data;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "program-service")
public interface ProgramServiceClient {

    @GetMapping("/api/programs/{id}")
    ProgramInfo getProgram(@PathVariable Long id);

    @Data
    class ProgramInfo {
        private Long programId;
        private String title;
        private String status;
    }
}
