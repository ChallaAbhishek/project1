package com.civicaid.application.client;

import lombok.Data;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "citizen-service")
public interface CitizenServiceClient {

    @GetMapping("/api/citizens/{id}")
    CitizenInfo getCitizen(@PathVariable Long id);

    @Data
    class CitizenInfo {
        private Long citizenId;
        private String name;
        private String status;
    }
}
