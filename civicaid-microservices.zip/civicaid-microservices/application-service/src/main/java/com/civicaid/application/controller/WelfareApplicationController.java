package com.civicaid.application.controller;

import com.civicaid.application.dto.request.WelfareApplicationRequest;
import com.civicaid.application.dto.response.WelfareApplicationResponse;
import com.civicaid.application.entity.WelfareApplication;
import com.civicaid.application.service.WelfareApplicationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
public class WelfareApplicationController {

    private final WelfareApplicationService applicationService;

    @PostMapping("/citizen/{citizenId}")
    public ResponseEntity<WelfareApplicationResponse> submit(
            @PathVariable Long citizenId,
            @Valid @RequestBody WelfareApplicationRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(applicationService.submit(citizenId, request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<WelfareApplicationResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(applicationService.getById(id));
    }

    @GetMapping("/citizen/{citizenId}")
    public ResponseEntity<Page<WelfareApplicationResponse>> getByCitizen(
            @PathVariable Long citizenId, Pageable pageable) {
        return ResponseEntity.ok(applicationService.getByCitizen(citizenId, pageable));
    }

    @GetMapping
    public ResponseEntity<Page<WelfareApplicationResponse>> getAll(Pageable pageable) {
        return ResponseEntity.ok(applicationService.getAll(pageable));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<WelfareApplicationResponse> updateStatus(
            @PathVariable Long id,
            @RequestParam WelfareApplication.ApplicationStatus status,
            @RequestParam(required = false) String remarks) {
        return ResponseEntity.ok(applicationService.updateStatus(id, status, remarks));
    }
}
