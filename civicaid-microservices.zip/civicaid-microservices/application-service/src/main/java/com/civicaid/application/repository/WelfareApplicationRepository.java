package com.civicaid.application.repository;

import com.civicaid.application.entity.WelfareApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WelfareApplicationRepository extends JpaRepository<WelfareApplication, Long> {
    Page<WelfareApplication> findByCitizenId(Long citizenId, Pageable pageable);
    Page<WelfareApplication> findByProgramId(Long programId, Pageable pageable);
    Page<WelfareApplication> findByStatus(WelfareApplication.ApplicationStatus status, Pageable pageable);
    boolean existsByCitizenIdAndProgramId(Long citizenId, Long programId);
}
