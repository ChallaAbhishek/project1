package com.civicaid.notification.service;

import com.civicaid.notification.dto.request.NotificationRequest;
import com.civicaid.notification.dto.response.NotificationResponse;
import com.civicaid.notification.entity.Notification;
import com.civicaid.notification.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationService {

    private final NotificationRepository notificationRepository;

    @Async
    @Transactional
    public void sendNotification(NotificationRequest request) {
        try {
            Notification.NotificationCategory category =
                    Notification.NotificationCategory.valueOf(request.getCategory());

            Notification notification = Notification.builder()
                    .userId(request.getUserId())
                    .entityId(request.getEntityId())
                    .message(request.getMessage())
                    .category(category)
                    .build();

            notificationRepository.save(notification);
            log.info("Notification sent to userId {}: {}", request.getUserId(), request.getMessage());
        } catch (Exception e) {
            log.error("Failed to send notification to userId {}: {}", request.getUserId(), e.getMessage());
        }
    }

    public Page<NotificationResponse> getUserNotifications(Long userId, Pageable pageable) {
        return notificationRepository.findByUserId(userId, pageable).map(this::mapToResponse);
    }

    public Page<NotificationResponse> getUnread(Long userId, Pageable pageable) {
        return notificationRepository.findByUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD, pageable)
                .map(this::mapToResponse);
    }

    public long getUnreadCount(Long userId) {
        return notificationRepository.countByUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD);
    }

    @Transactional
    public void markAsRead(Long id) {
        Notification n = notificationRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Notification not found: " + id));
        n.setStatus(Notification.NotificationStatus.READ);
        n.setReadAt(LocalDateTime.now());
        notificationRepository.save(n);
    }

    @Transactional
    public int markAllAsRead(Long userId) {
        return notificationRepository.markAllAsReadByUser(userId);
    }

    @Transactional
    public void delete(Long id) {
        if (!notificationRepository.existsById(id))
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Notification not found: " + id);
        notificationRepository.deleteById(id);
    }

    private NotificationResponse mapToResponse(Notification n) {
        return NotificationResponse.builder()
                .notificationId(n.getNotificationId())
                .userId(n.getUserId())
                .entityId(n.getEntityId())
                .message(n.getMessage())
                .category(n.getCategory())
                .status(n.getStatus())
                .createdDate(n.getCreatedDate())
                .readAt(n.getReadAt())
                .build();
    }
}
