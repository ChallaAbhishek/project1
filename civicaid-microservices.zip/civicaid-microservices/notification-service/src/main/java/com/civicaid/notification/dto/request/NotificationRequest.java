package com.civicaid.notification.dto.request;

import com.civicaid.notification.entity.Notification;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class NotificationRequest {
    @NotNull private Long userId;
    private Long entityId;
    @NotBlank private String message;
    @NotNull private String category;
}
