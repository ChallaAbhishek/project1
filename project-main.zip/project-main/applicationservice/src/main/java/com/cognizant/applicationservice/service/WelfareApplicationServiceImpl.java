package com.cognizant.applicationservice.service;

import com.cognizant.applicationservice.dao.WelfareApplicationRepository;
import com.cognizant.applicationservice.dto.*;
import com.cognizant.applicationservice.entity.WelfareApplication;
import com.cognizant.applicationservice.exception.ResourceNotFoundException;
import com.cognizant.applicationservice.externalservice.NotificationServiceClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class WelfareApplicationServiceImpl implements WelfareApplicationService {

    private final WelfareApplicationRepository applicationRepository;
    private final NotificationServiceClient notificationServiceClient;

    @Override
    public ApplicationResponseDto createApplication(ApplicationRequestDto dto) {
        WelfareApplication app = WelfareApplication.builder()
                .citizenId(dto.getCitizenId()).programId(dto.getProgramId()).build();
        ApplicationResponseDto saved = toDto(applicationRepository.save(app));
        try {
            notificationServiceClient.sendNotification(Map.of(
                "userId", dto.getCitizenId(), "entityId", saved.getApplicationId(),
                "message", "Your welfare application has been submitted successfully.",
                "category", "APPLICATION"));
        } catch (Exception ignored) {}
        return saved;
    }

    @Override
    public ApplicationResponseDto getApplicationById(Long id) {
        return toDto(applicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found: " + id)));
    }

    @Override
    public List<ApplicationResponseDto> getApplicationsByCitizen(Long citizenId) {
        return applicationRepository.findByCitizenId(citizenId).stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public List<ApplicationResponseDto> getAllApplications() {
        return applicationRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public ApplicationResponseDto updateStatus(Long id, String status) {
        WelfareApplication app = applicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found: " + id));
        app.setStatus(WelfareApplication.ApplicationStatus.valueOf(status.toUpperCase()));
        ApplicationResponseDto saved = toDto(applicationRepository.save(app));
        try {
            notificationServiceClient.sendNotification(Map.of(
                "userId", app.getCitizenId(), "entityId", id,
                "message", "Your application status has been updated to: " + status,
                "category", "APPLICATION"));
        } catch (Exception ignored) {}
        return saved;
    }

    private ApplicationResponseDto toDto(WelfareApplication a) {
        return ApplicationResponseDto.builder()
                .applicationId(a.getApplicationId()).citizenId(a.getCitizenId())
                .programId(a.getProgramId()).submittedDate(a.getSubmittedDate())
                .status(a.getStatus()).createdAt(a.getCreatedAt()).build();
    }
}
