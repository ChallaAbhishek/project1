package com.cognizant.applicationservice.service;

import com.cognizant.applicationservice.dto.*;
import java.util.List;

public interface EligibilityCheckService {
    EligibilityCheckResponseDto createCheck(EligibilityCheckRequestDto dto);
    EligibilityCheckResponseDto getCheckById(Long id);
    List<EligibilityCheckResponseDto> getChecksByApplication(Long applicationId);
}
