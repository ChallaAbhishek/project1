package com.cognizant.disbursementservice.controller;
import com.cognizant.disbursementservice.dto.*; import com.cognizant.disbursementservice.service.DisbursementService;
import lombok.RequiredArgsConstructor; import org.springframework.http.*; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/disbursements") @RequiredArgsConstructor
public class DisbursementController {
    private final DisbursementService disbursementService;
    @PostMapping @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<DisbursementResponseDto> create(@RequestBody DisbursementRequestDto dto) { return ResponseEntity.status(HttpStatus.CREATED).body(disbursementService.createDisbursement(dto)); }
    @GetMapping("/{id}") @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<DisbursementResponseDto> getById(@PathVariable Long id) { return ResponseEntity.ok(disbursementService.getDisbursementById(id)); }
    @GetMapping("/application/{applicationId}") @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<List<DisbursementResponseDto>> getByApplication(@PathVariable Long applicationId) { return ResponseEntity.ok(disbursementService.getDisbursementsByApplication(applicationId)); }
    @GetMapping @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    public ResponseEntity<List<DisbursementResponseDto>> getAll() { return ResponseEntity.ok(disbursementService.getAllDisbursements()); }
    @PatchMapping("/{id}/status") @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<DisbursementResponseDto> updateStatus(@PathVariable Long id, @RequestParam String status) { return ResponseEntity.ok(disbursementService.updateStatus(id, status)); }
}
