package com.cognizant.disbursementservice.service;
import com.cognizant.disbursementservice.dto.*; import java.util.List;
public interface DisbursementService {
    DisbursementResponseDto createDisbursement(DisbursementRequestDto dto);
    DisbursementResponseDto getDisbursementById(Long id);
    List<DisbursementResponseDto> getDisbursementsByApplication(Long applicationId);
    List<DisbursementResponseDto> getAllDisbursements();
    DisbursementResponseDto updateStatus(Long id, String status);
}
