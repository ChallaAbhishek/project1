package com.cognizant.disbursementservice.externalservice;
import org.springframework.cloud.openfeign.FeignClient; import org.springframework.web.bind.annotation.*; import java.util.Map;
@FeignClient(name = "notification-service")
public interface NotificationServiceClient { @PostMapping("/notifications/internal") Object sendNotification(@RequestBody Map<String, Object> payload); }
