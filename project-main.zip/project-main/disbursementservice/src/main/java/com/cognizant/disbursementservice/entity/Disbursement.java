package com.cognizant.disbursementservice.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.*; import java.math.BigDecimal; import java.time.*;
@Entity @Table(name="disbursements") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Disbursement {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long disbursementId;
    @Column(nullable=false) private Long applicationId;
    @Column(nullable=false) private BigDecimal amount;
    @Builder.Default private LocalDate date = LocalDate.now();
    @Enumerated(EnumType.STRING) @Builder.Default private DisbursementStatus status = DisbursementStatus.PENDING;
    @CreationTimestamp private LocalDateTime createdAt;
    @UpdateTimestamp private LocalDateTime updatedAt;
    public enum DisbursementStatus { PENDING, PROCESSED, FAILED, CANCELLED }
}
