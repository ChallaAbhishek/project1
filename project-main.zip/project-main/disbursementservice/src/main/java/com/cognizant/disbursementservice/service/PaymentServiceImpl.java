package com.cognizant.disbursementservice.service;
import com.cognizant.disbursementservice.dao.PaymentRepository; import com.cognizant.disbursementservice.dto.*; import com.cognizant.disbursementservice.entity.Payment;
import com.cognizant.disbursementservice.exception.ResourceNotFoundException; import lombok.RequiredArgsConstructor; import org.springframework.stereotype.Service; import java.util.List; import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {
    private final PaymentRepository paymentRepository;
    @Override public PaymentResponseDto createPayment(PaymentRequestDto dto) { Payment p = Payment.builder().disbursementId(dto.getDisbursementId()).method(dto.getMethod()).build(); return toDto(paymentRepository.save(p)); }
    @Override public PaymentResponseDto getPaymentById(Long id) { return toDto(paymentRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Payment not found: " + id))); }
    @Override public List<PaymentResponseDto> getPaymentsByDisbursement(Long disbursementId) { return paymentRepository.findByDisbursementId(disbursementId).stream().map(this::toDto).collect(Collectors.toList()); }
    private PaymentResponseDto toDto(Payment p) { return PaymentResponseDto.builder().paymentId(p.getPaymentId()).disbursementId(p.getDisbursementId()).method(p.getMethod()).date(p.getDate()).status(p.getStatus()).build(); }
}
