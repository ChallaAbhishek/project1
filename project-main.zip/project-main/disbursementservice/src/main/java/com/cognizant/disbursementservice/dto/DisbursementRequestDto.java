package com.cognizant.disbursementservice.dto;
import lombok.*; import java.math.BigDecimal;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class DisbursementRequestDto { private Long applicationId; private BigDecimal amount; }
