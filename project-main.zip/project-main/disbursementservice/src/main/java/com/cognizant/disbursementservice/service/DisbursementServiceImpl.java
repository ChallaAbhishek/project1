package com.cognizant.disbursementservice.service;
import com.cognizant.disbursementservice.dao.DisbursementRepository; import com.cognizant.disbursementservice.dto.*; import com.cognizant.disbursementservice.entity.Disbursement;
import com.cognizant.disbursementservice.exception.ResourceNotFoundException; import com.cognizant.disbursementservice.externalservice.NotificationServiceClient;
import lombok.RequiredArgsConstructor; import org.springframework.stereotype.Service; import java.util.*; import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class DisbursementServiceImpl implements DisbursementService {
    private final DisbursementRepository disbursementRepository;
    private final NotificationServiceClient notificationServiceClient;
    @Override public DisbursementResponseDto createDisbursement(DisbursementRequestDto dto) {
        Disbursement d = Disbursement.builder().applicationId(dto.getApplicationId()).amount(dto.getAmount()).build();
        DisbursementResponseDto saved = toDto(disbursementRepository.save(d));
        try { notificationServiceClient.sendNotification(Map.of("entityId", saved.getDisbursementId(), "message", "Disbursement of " + dto.getAmount() + " has been initiated.", "category", "DISBURSEMENT")); } catch (Exception ignored) {}
        return saved;
    }
    @Override public DisbursementResponseDto getDisbursementById(Long id) { return toDto(disbursementRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Disbursement not found: " + id))); }
    @Override public List<DisbursementResponseDto> getDisbursementsByApplication(Long applicationId) { return disbursementRepository.findByApplicationId(applicationId).stream().map(this::toDto).collect(Collectors.toList()); }
    @Override public List<DisbursementResponseDto> getAllDisbursements() { return disbursementRepository.findAll().stream().map(this::toDto).collect(Collectors.toList()); }
    @Override public DisbursementResponseDto updateStatus(Long id, String status) {
        Disbursement d = disbursementRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Disbursement not found: " + id));
        d.setStatus(Disbursement.DisbursementStatus.valueOf(status.toUpperCase()));
        return toDto(disbursementRepository.save(d));
    }
    private DisbursementResponseDto toDto(Disbursement d) { return DisbursementResponseDto.builder().disbursementId(d.getDisbursementId()).applicationId(d.getApplicationId()).amount(d.getAmount()).date(d.getDate()).status(d.getStatus()).createdAt(d.getCreatedAt()).build(); }
}
