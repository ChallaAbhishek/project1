package com.cognizant.citizenservice.dao;

import com.cognizant.citizenservice.entity.Citizen;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface CitizenRepository extends JpaRepository<Citizen, Long> {
    Optional<Citizen> findByUserId(Long userId);
    List<Citizen> findByStatus(Citizen.CitizenStatus status);
}
