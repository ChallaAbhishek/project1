package com.cognizant.complianceservice.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditRequestDto { private Long officerId; private String scope; private String findings; }
