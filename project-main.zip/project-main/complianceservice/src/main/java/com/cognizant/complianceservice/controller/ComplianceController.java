package com.cognizant.complianceservice.controller;
import com.cognizant.complianceservice.dto.*; import com.cognizant.complianceservice.service.ComplianceService;
import lombok.RequiredArgsConstructor; import org.springframework.http.*; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/compliance") @RequiredArgsConstructor
public class ComplianceController {
    private final ComplianceService complianceService;
    @PostMapping @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<ComplianceRecordResponseDto> create(@RequestBody ComplianceRecordRequestDto dto) { return ResponseEntity.status(HttpStatus.CREATED).body(complianceService.createRecord(dto)); }
    @GetMapping("/{id}") @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<ComplianceRecordResponseDto> getById(@PathVariable Long id) { return ResponseEntity.ok(complianceService.getRecordById(id)); }
    @GetMapping @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','ADMINISTRATOR')")
    public ResponseEntity<List<ComplianceRecordResponseDto>> getAll() { return ResponseEntity.ok(complianceService.getAllRecords()); }
    @GetMapping("/entity/{entityId}") @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<List<ComplianceRecordResponseDto>> getByEntity(@PathVariable Long entityId) { return ResponseEntity.ok(complianceService.getRecordsByEntity(entityId)); }
}
