package com.cognizant.complianceservice.config;
import jakarta.servlet.FilterChain; import jakarta.servlet.ServletException; import jakarta.servlet.http.HttpServletRequest; import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; import org.springframework.security.core.authority.SimpleGrantedAuthority; import org.springframework.security.core.context.SecurityContextHolder; import org.springframework.stereotype.Component; import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException; import java.util.List;
@Component
public class InternalServiceAuthFilter extends OncePerRequestFilter {
    @Override protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        String internalKey = request.getHeader("X-Internal-Service-Key"); String gatewayRole = request.getHeader("X-User-Role"); String username = request.getHeader("X-User-Name");
        if ("MySecretKey123".equals(internalKey)) { SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken("internal", null, List.of(new SimpleGrantedAuthority("ROLE_SERVICE"))));
        } else if (gatewayRole != null) { String fr = gatewayRole.startsWith("ROLE_") ? gatewayRole : "ROLE_" + gatewayRole; SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(username, null, List.of(new SimpleGrantedAuthority(fr))));
        } else { SecurityContextHolder.getContext().setAuthentication(null); }
        chain.doFilter(request, response);
    }
}
