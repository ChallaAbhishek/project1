package com.cognizant.complianceservice.service;
import com.cognizant.complianceservice.dao.ComplianceRecordRepository; import com.cognizant.complianceservice.dto.*; import com.cognizant.complianceservice.entity.ComplianceRecord;
import com.cognizant.complianceservice.exception.ResourceNotFoundException; import lombok.RequiredArgsConstructor; import org.springframework.stereotype.Service; import java.util.List; import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class ComplianceServiceImpl implements ComplianceService {
    private final ComplianceRecordRepository recordRepository;
    @Override public ComplianceRecordResponseDto createRecord(ComplianceRecordRequestDto dto) {
        ComplianceRecord r = ComplianceRecord.builder().entityId(dto.getEntityId()).type(dto.getType()).result(dto.getResult()).notes(dto.getNotes()).build();
        return toDto(recordRepository.save(r));
    }
    @Override public ComplianceRecordResponseDto getRecordById(Long id) { return toDto(recordRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Record not found: " + id))); }
    @Override public List<ComplianceRecordResponseDto> getAllRecords() { return recordRepository.findAll().stream().map(this::toDto).collect(Collectors.toList()); }
    @Override public List<ComplianceRecordResponseDto> getRecordsByEntity(Long entityId) { return recordRepository.findByEntityId(entityId).stream().map(this::toDto).collect(Collectors.toList()); }
    private ComplianceRecordResponseDto toDto(ComplianceRecord r) { return ComplianceRecordResponseDto.builder().complianceId(r.getComplianceId()).entityId(r.getEntityId()).type(r.getType()).result(r.getResult()).date(r.getDate()).notes(r.getNotes()).createdAt(r.getCreatedAt()).build(); }
}
