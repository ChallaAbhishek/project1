package com.cognizant.userservice.service;

import com.cognizant.userservice.dto.RegisterRequestDto;
import com.cognizant.userservice.dto.RegisterResponseDto;
import com.cognizant.userservice.dto.UserDto;

import java.util.List;

public interface UserService {

    RegisterResponseDto createUsers(RegisterRequestDto registerRequestDto);
    UserDto findByEmail(String email);

    List<RegisterResponseDto>getAllUser();

    void deleteUser(Long id);

    RegisterResponseDto getUserById(Long id);
}
