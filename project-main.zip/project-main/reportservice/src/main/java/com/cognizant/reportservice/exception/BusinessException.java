package com.cognizant.reportservice.exception;
public class BusinessException extends RuntimeException { public BusinessException(String m) { super(m); } }
