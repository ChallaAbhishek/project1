package com.cognizant.programservice.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.*; import java.time.LocalDateTime;
@Entity @Table(name="schemes") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Scheme {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long schemeId;
    @Column(nullable=false) private Long programId;
    @Column(nullable=false) private String title;
    @Column(columnDefinition="TEXT") private String description;
    @Column(columnDefinition="TEXT") private String eligibilityCriteria;
    @Enumerated(EnumType.STRING) @Builder.Default private SchemeStatus status = SchemeStatus.ACTIVE;
    @CreationTimestamp private LocalDateTime createdAt;
    public enum SchemeStatus { ACTIVE, INACTIVE }
}
