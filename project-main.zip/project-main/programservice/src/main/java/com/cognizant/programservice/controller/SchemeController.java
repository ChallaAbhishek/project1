package com.cognizant.programservice.controller;
import com.cognizant.programservice.dto.*; import com.cognizant.programservice.service.SchemeService;
import lombok.RequiredArgsConstructor; import org.springframework.http.*; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/schemes") @RequiredArgsConstructor
public class SchemeController {
    private final SchemeService schemeService;
    @PostMapping @PreAuthorize("hasAnyRole('PROGRAM_MANAGER','ADMINISTRATOR')")
    public ResponseEntity<SchemeResponseDto> create(@RequestBody SchemeRequestDto dto) { return ResponseEntity.status(HttpStatus.CREATED).body(schemeService.createScheme(dto)); }
    @GetMapping("/{id}") @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<SchemeResponseDto> getById(@PathVariable Long id) { return ResponseEntity.ok(schemeService.getSchemeById(id)); }
    @GetMapping @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<List<SchemeResponseDto>> getAll() { return ResponseEntity.ok(schemeService.getAllSchemes()); }
    @GetMapping("/program/{programId}") @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<List<SchemeResponseDto>> getByProgram(@PathVariable Long programId) { return ResponseEntity.ok(schemeService.getSchemesByProgram(programId)); }
}
