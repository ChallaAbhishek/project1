package com.cognizant.programservice.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.*; import java.math.BigDecimal; import java.time.*; 
@Entity @Table(name="programs") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Program {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long programId;
    @Column(nullable=false) private String title;
    @Column(columnDefinition="TEXT") private String description;
    private LocalDate startDate; private LocalDate endDate;
    private BigDecimal budget;
    @Enumerated(EnumType.STRING) @Builder.Default private ProgramStatus status = ProgramStatus.ACTIVE;
    @CreationTimestamp private LocalDateTime createdAt;
    @UpdateTimestamp private LocalDateTime updatedAt;
    public enum ProgramStatus { ACTIVE, INACTIVE, COMPLETED, SUSPENDED }
}
