package com.cognizant.programservice.service;
import com.cognizant.programservice.dto.*; import java.util.List;
public interface SchemeService {
    SchemeResponseDto createScheme(SchemeRequestDto dto);
    SchemeResponseDto getSchemeById(Long id);
    List<SchemeResponseDto> getSchemesByProgram(Long programId);
    List<SchemeResponseDto> getAllSchemes();
}
