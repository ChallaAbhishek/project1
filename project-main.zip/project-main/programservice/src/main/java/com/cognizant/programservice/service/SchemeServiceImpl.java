package com.cognizant.programservice.service;
import com.cognizant.programservice.dao.SchemeRepository; import com.cognizant.programservice.dto.*; import com.cognizant.programservice.entity.Scheme; import com.cognizant.programservice.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor; import org.springframework.stereotype.Service; import java.util.List; import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class SchemeServiceImpl implements SchemeService {
    private final SchemeRepository schemeRepository;
    @Override public SchemeResponseDto createScheme(SchemeRequestDto dto) {
        Scheme s = Scheme.builder().programId(dto.getProgramId()).title(dto.getTitle()).description(dto.getDescription()).eligibilityCriteria(dto.getEligibilityCriteria()).build();
        return toDto(schemeRepository.save(s));
    }
    @Override public SchemeResponseDto getSchemeById(Long id) { return toDto(schemeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Scheme not found: " + id))); }
    @Override public List<SchemeResponseDto> getSchemesByProgram(Long programId) { return schemeRepository.findByProgramId(programId).stream().map(this::toDto).collect(Collectors.toList()); }
    @Override public List<SchemeResponseDto> getAllSchemes() { return schemeRepository.findAll().stream().map(this::toDto).collect(Collectors.toList()); }
    private SchemeResponseDto toDto(Scheme s) { return SchemeResponseDto.builder().schemeId(s.getSchemeId()).programId(s.getProgramId()).title(s.getTitle()).description(s.getDescription()).eligibilityCriteria(s.getEligibilityCriteria()).status(s.getStatus()).createdAt(s.getCreatedAt()).build(); }
}
