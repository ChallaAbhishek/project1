package com.cognizant.programservice.service;
import com.cognizant.programservice.dto.*; import java.util.List;
public interface ProgramService {
    ProgramResponseDto createProgram(ProgramRequestDto dto);
    ProgramResponseDto getProgramById(Long id);
    List<ProgramResponseDto> getAllPrograms();
    ProgramResponseDto updateProgram(Long id, ProgramRequestDto dto);
    void deleteProgram(Long id);
}
