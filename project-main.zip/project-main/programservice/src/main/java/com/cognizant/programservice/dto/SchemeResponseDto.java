package com.cognizant.programservice.dto;
import com.cognizant.programservice.entity.Scheme; import lombok.*; import java.time.LocalDateTime;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class SchemeResponseDto { private Long schemeId; private Long programId; private String title; private String description; private String eligibilityCriteria; private Scheme.SchemeStatus status; private LocalDateTime createdAt; }
