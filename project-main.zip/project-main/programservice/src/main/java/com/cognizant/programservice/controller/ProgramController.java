package com.cognizant.programservice.controller;
import com.cognizant.programservice.dto.*; import com.cognizant.programservice.service.ProgramService;
import lombok.RequiredArgsConstructor; import org.springframework.http.*; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/programs") @RequiredArgsConstructor
public class ProgramController {
    private final ProgramService programService;
    @PostMapping @PreAuthorize("hasAnyRole('PROGRAM_MANAGER','ADMINISTRATOR')")
    public ResponseEntity<ProgramResponseDto> create(@RequestBody ProgramRequestDto dto) { return ResponseEntity.status(HttpStatus.CREATED).body(programService.createProgram(dto)); }
    @GetMapping("/{id}") @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<ProgramResponseDto> getById(@PathVariable Long id) { return ResponseEntity.ok(programService.getProgramById(id)); }
    @GetMapping @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<List<ProgramResponseDto>> getAll() { return ResponseEntity.ok(programService.getAllPrograms()); }
    @PutMapping("/{id}") @PreAuthorize("hasAnyRole('PROGRAM_MANAGER','ADMINISTRATOR')")
    public ResponseEntity<ProgramResponseDto> update(@PathVariable Long id, @RequestBody ProgramRequestDto dto) { return ResponseEntity.ok(programService.updateProgram(id, dto)); }
    @DeleteMapping("/{id}") @PreAuthorize("hasRole('ADMINISTRATOR')")
    public ResponseEntity<String> delete(@PathVariable Long id) { programService.deleteProgram(id); return ResponseEntity.ok("Program deleted"); }
}
