package com.cognizant.programservice.dto;
import com.cognizant.programservice.entity.Program; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ProgramRequestDto { private String title; private String description; private LocalDate startDate; private LocalDate endDate; private BigDecimal budget; private Program.ProgramStatus status; }
