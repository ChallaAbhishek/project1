package com.cognizant.programservice.dto;
import lombok.*; 
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class SchemeRequestDto { private Long programId; private String title; private String description; private String eligibilityCriteria; }
